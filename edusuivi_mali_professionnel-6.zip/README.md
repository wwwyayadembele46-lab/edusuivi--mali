# EduSuivi Mali — version professionnelle

## Fonctionnalités
- Comptes réels Parent / Professeur / Administration
- Mots de passe hachés avec Werkzeug
- Base SQLite
- Gestion des élèves/classes/matières
- Notes et observations
- Publications : parents en lecture seule
- Recherche d'élèves
- Bulletin PDF avec ReportLab
- Préparation pour photos de classes via `/uploads`

## Installation
1. Installer Python 3.10+
2. `python -m venv .venv`
3. Activer l'environnement virtuel
4. `pip install -r requirements.txt`
5. `python app.py`
6. Ouvrir `http://127.0.0.1:5000`

## Compte administrateur initial
E-mail : `admin@edusuivi.ml`
Mot de passe : `Admin@12345`

IMPORTANT : changer ce mot de passe et la clé secrète avant une mise en production.

## Mise en production
Utiliser HTTPS, une vraie clé secrète via variable d'environnement, sauvegardes de base de données, contrôle des types de fichiers uploadés, limitation de débit, CSRF et un serveur WSGI (ex. Gunicorn). Pour une école importante, PostgreSQL est recommandé à la place de SQLite.
